import type { BuyerSignal, LeadCandidate } from "./types";

type SerperOrganicResult = {
  title?: string;
  link?: string;
  snippet?: string;
  position?: number;
};

type SerperResponse = {
  organic?: SerperOrganicResult[];
  message?: string;
};

const signalPatterns: Array<[BuyerSignal, RegExp]> = [
  ["importer", /\b(import|importer|ithalat|international sourcing|global sourcing)\b/i],
  ["multi_brand", /\b(multi[- ]brand|designer brands|brands we carry|our brands)\b/i],
  ["premium_positioning", /\b(luxury|premium|designer|couture|exclusive|high[- ]end)\b/i],
  ["evening_dress_focus", /\b(evening|occasion|gala|prom|abiye|gece elbisesi|cocktail dress)\b/i],
  ["wholesale", /\b(wholesale|toptan|distributor|distribution|trade|retail partners)\b/i],
  ["international_brands", /\b(international brands|global brands|designer labels)\b/i],
  ["physical_stores", /\b(store|stores|showroom|boutique|locations)\b/i],
  ["active_social", /\b(instagram|facebook|tiktok|social)\b/i],
];

const blockedHosts = [
  "instagram.com", "facebook.com", "youtube.com", "tiktok.com", "pinterest.com",
  "linkedin.com", "x.com", "twitter.com", "amazon.", "aliexpress.", "trendyol.",
  "hepsiburada.", "wikipedia.org",
];

function companyFromTitle(title: string, hostname: string) {
  const name = title.split(/\s+[|–—-]\s+/)[0]?.trim();
  if (name && name.length >= 2 && name.length <= 80) return name;
  return hostname.replace(/^www\./, "").split(".")[0].replace(/[-_]/g, " ");
}

function toCandidate(result: SerperOrganicResult): LeadCandidate | null {
  if (!result.link || !result.title) return null;

  let url: URL;
  try {
    url = new URL(result.link);
  } catch {
    return null;
  }

  const text = `${result.title} ${result.snippet ?? ""}`;
  const signals = signalPatterns
    .filter(([, pattern]) => pattern.test(text))
    .map(([signal]) => signal);

  if (!signals.includes("evening_dress_focus") && !signals.includes("premium_positioning")) {
    return null;
  }

  const hostname = url.hostname.toLowerCase().replace(/^www\./, "");
  if (blockedHosts.some((host) => hostname === host || hostname.endsWith(`.${host}`) || hostname.includes(host))) {
    return null;
  }
  return {
    id: hostname,
    company: companyFromTitle(result.title, hostname),
    website: url.origin,
    country: "Turkey",
    city: "",
    customerType: signals.includes("wholesale")
      ? "Importer / Distributor"
      : signals.includes("multi_brand")
        ? "Multi-brand Retailer"
        : "Fashion Retailer",
    description: result.snippet ?? result.title,
    sourceUrl: result.link,
    signals,
    evidence: [result.title, result.snippet].filter(
      (value): value is string => Boolean(value),
    ),
  };
}

export async function searchWithSerper(queries: string[]) {
  const apiKey = process.env.SERPER_API_KEY;
  if (!apiKey) throw new Error("尚未配置 SERPER_API_KEY。");

  const tasks = queries.flatMap((query) =>
    [1, 2, 3].map((page) => ({ query, page })),
  );
  const responses: SerperOrganicResult[][] = [];
  for (let index = 0; index < tasks.length; index += 5) {
    const batch = await Promise.all(
      tasks.slice(index, index + 5).map(async ({ query, page }) => {
      let response: Response | undefined;
      for (let attempt = 0; attempt < 3; attempt += 1) {
        response = await fetch("https://google.serper.dev/search", {
          method: "POST",
          headers: {
            "X-API-KEY": apiKey,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            q: query,
            gl: "tr",
            hl: "en",
            location: "Turkey",
            num: 10,
            page,
          }),
          cache: "no-store",
          signal: AbortSignal.timeout(20_000),
        });
        if (response.status !== 429) break;
        await new Promise((resolve) => setTimeout(resolve, 700 * (attempt + 1)));
      }

      if (!response) throw new Error("Serper 搜索没有返回响应。");
      if (!response.ok) {
        const errorBody = await response.text();
        let detail = errorBody.trim();
        try {
          const parsed = JSON.parse(errorBody) as { message?: string; error?: string };
          detail = parsed.message ?? parsed.error ?? detail;
        } catch {
          // Keep the plain-text response when Serper does not return JSON.
        }
        const safeDetail = detail.slice(0, 180);
        throw new Error(
          `Serper 搜索请求失败（${response.status}）${safeDetail ? `：${safeDetail}` : "。"}`
        );
      }

      const data = (await response.json()) as SerperResponse;
      if (data.message) throw new Error(data.message);
      return data.organic ?? [];
      }),
    );
    responses.push(...batch);
  }

  const unique = new Map<string, LeadCandidate>();
  responses.flat().forEach((result) => {
    const candidate = toCandidate(result);
    if (!candidate) return;
    const existing = unique.get(candidate.id);
    if (!existing || candidate.signals.length > existing.signals.length) {
      unique.set(candidate.id, candidate);
    }
  });

  return [...unique.values()];
}
